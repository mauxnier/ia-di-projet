import os
import glob
from lxml import etree

# Définir une fonction pour analyser un fichier XML et le convertir en liste de dictionnaires
def parse_xml_file(xml_file):
    flow_data = []
    tree = etree.parse(xml_file)
    root = tree.getroot()

    for flow_element in root:
        flow_dict = {}
        for child in flow_element:
            flow_dict[child.tag] = child.text
        flow_data.append(flow_dict)

    return flow_data

# Spécifiez le répertoire contenant les fichiers XML
xml_files_dir = 'TRAIN_ENSIBS'

# Obtenez une liste de tous les fichiers XML du répertoire
xml_files = glob.glob(os.path.join(xml_files_dir, '*.xml'))

# Initialisez une liste vide pour stocker toutes les données de flux
all_flow_data = []

# Parcourez chaque fichier XML et analysez-le
for xml_file in xml_files:
    flow_data = parse_xml_file(xml_file)

    origin = os.path.basename(xml_file)  # Obtenez le nom du fichier d'origine
     # Ajoutez le champ "origin" à chaque élément de flow_data
    for flow in flow_data:
        flow["origin"] = origin

    all_flow_data.extend(flow_data)

# Désormais, all_flow_data contient une liste de dictionnaires, où chaque dictionnaire correspond à un seul flux
# Vous pouvez accéder et manipuler les données selon vos besoins

print("Longueur: ", len(all_flow_data))
print("Premier element: ", all_flow_data[0])